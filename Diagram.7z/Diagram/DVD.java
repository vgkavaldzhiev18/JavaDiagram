package Diagram;

public class DVD extends AudioVideo{

	private String director;

	public String getDirector() {
		return director;
	}

	public void setDirector(String director) {
		this.director = director;
	}
	
	public void print(String director) {
		System.out.println(director);
	}
	
}
