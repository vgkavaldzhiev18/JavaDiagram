package Diagram;

public class CD extends  AudioVideo {

	private String artist;
	private int numberOfTracks;
	public String getArtist() {
		return artist;
	}
	public void setArtist(String artist) {
		this.artist = artist;
	}
	public int getNumberOfTracks() {
		return numberOfTracks;
	}
	public void setNumberOfTracks(int numberOfTracks) {
		this.numberOfTracks = numberOfTracks;
	}
	
	public void print( String artist,int numberOfTracks) {
		System.out.println(artist);
		System.out.println(numberOfTracks);
	}
	
}
